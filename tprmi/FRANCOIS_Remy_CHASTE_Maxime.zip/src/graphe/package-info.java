/**
 * Transfert en RMI selon une topologie en graphe
 */
/**
 * @author Chaste Maxime and Remy Francois
 *
 */
package graphe;