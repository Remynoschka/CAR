/**
 *
 * Transfert en RMI selon une topologie en arbre
 * 
 *  @author Maxime Chaste and Remy Francois
 *
 */
package arbre;